"Exports of mermaid2"

# export the dumps function (for producing a JS object)
from .pyjs import dumps

# export the fence_mermaid for pymdownx.superfences
from .fence import fence_mermaid, fence_mermaid_custom


