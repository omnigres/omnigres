// jp is the country code, while ja is the language code
// a new lunr.ja.js has been created, but in order to
// keep the backward compatibility, we'll leave the lunr.jp.js
// here for a while, and just make it use the new lunr.ja.js
module.exports = require('./lunr.ja');